<?php

namespace PostsRemover\Admin\Controller;

use XF\Admin\Controller\AbstractController;

class PostsRemover extends AbstractController
{
    public function actionIndex()
    {
        return $this->view('PostsRemover\Criteria', 'posts_remover_criteria');
    }

    public function actionRemove()
    {
        $postCriteriaInput = $this->filter('post_criteria', 'array');

        /** @var \PostsRemover\Criteria\Post $postCriteria */
        $postCriteria = $this->app()->criteria('PostsRemover:Post', $postCriteriaInput);

        $postCriteria->setMatchOnEmpty(false); // <-- If no criteria selected, nothing will be removed

        // Getting all forum posts
        $posts = $this->finder('XF:Post')->fetch();

        $deletedCounter = 0;

        /** @var \XF\Entity\Post $post */
        foreach ($posts as $post)
        {
            if ($postCriteria->isMatchedPost($post)) // <-- Checking the post against selected criteria
            {
                $post->delete(); // Deleting it if the post matches the selected criteria
                $deletedCounter++;
            }
        }

        return $this->message('Done! ' . $deletedCounter . ' posts were removed!');
    }
}