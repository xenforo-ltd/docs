<?php

namespace PostsRemover\Criteria;

use XF\Criteria\AbstractCriteria;

class Post extends AbstractCriteria
{
    // Post has at least X likes
    protected function _matchLikeCount(array $data, \XF\Entity\Post $post)
    {
        return ($post->likes && $post->likes >= $data['likes']);
    }

    // Post author has an X username
    protected function _matchUsername(array $data, \XF\Entity\Post $post)
    {
        return $post->username === $data['username'];
    }

    // Post was edited at least X times
    protected function _matchEditedCount(array $data, \XF\Entity\Post $post)
    {
        return $post->edit_count && $post->edit_count >= $data['count'];
    }

    /* ================ AND SO ON.... ================ */

    public function isMatchedPost(\XF\Entity\Post $post)
    {
        if (!$this->criteria)
        {
            return $this->matchOnEmpty;
        }

        foreach ($this->criteria AS $criterion)
        {
            $rule = $criterion['rule'];
            $data = $criterion['data'];

            $specialResult = $this->isSpecialMatchedPost($rule, $data, $post);
            if ($specialResult === false)
            {
                return false;
            }
            else if ($specialResult === true)
            {
                continue;
            }

            $method = '_match' . \XF\Util\Php::camelCase($rule);
            if (method_exists($this, $method))
            {
                $result = $this->$method($data, $post);
                if (!$result)
                {
                    return false;
                }
            }
            else
            {
                if (!$this->isUnknownMatched($rule, $data, $post))
                {
                    return false;
                }
            }
        }

        return true;
    }

    protected function isSpecialMatchedPost($rule, array $data, \XF\Entity\Post $post)
    {
        return null;
    }

    protected function isUnknownMatchedPost($rule, array $data, \XF\Entity\Post $post)
    {
        return false;
    }
}