<?php

namespace XFDocs;

class EventsListener
{
    public static function criteriaUser($rule, array $data, \XF\Entity\User $user, &$returnValue)
    {
        switch ($rule)
        {
            case 'likes_on_single':

                // Getting the database
                $db = \XF::db();

                // Database query for selecting the maximum number of likes for single user post
                $query = "SELECT `likes` FROM `xf_post` WHERE `user_id` = ? ORDER BY `likes` DESC LIMIT 1";

                // Retrieving the maximum number of likes
                $likes = $db->fetchOne($query, [$user->user_id]);

                // Checking that we have a result from database (we do expect a number)
                if (is_int($likes)) {
                    // Returning true if user has a message with X or more likes or false if he has not
                    $returnValue = ($likes >= $data['likes']);
                } else {
                    $returnValue = false;
                }

                break;
        }
    }
}