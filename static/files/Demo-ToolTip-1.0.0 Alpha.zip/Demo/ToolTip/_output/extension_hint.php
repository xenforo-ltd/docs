<?php

// ################## THIS IS A GENERATED FILE ##################
// DO NOT EDIT DIRECTLY. EDIT THE CLASS EXTENSIONS IN THE CONTROL PANEL.

/**
 * @noinspection PhpIllegalPsrClassPathInspection
 * @noinspection PhpMultipleClassesDeclarationsInOneFile
 */

namespace Demo\ToolTip\XF\Pub\Controller
{
	class XFCP_MemberController extends \XF\Pub\Controller\MemberController {}
}
