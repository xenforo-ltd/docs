<?php

namespace Demo\ToolTip\XF\Pub\Controller;

use XF;
use XF\Mvc\ParameterBag;
use XF\Mvc\Reply\Exception;
use XF\Mvc\Reply\View;
use XF\Pub\Controller\MemberController as XFMember;

class MemberController extends XFMember
{
    public function actionTooltip(ParameterBag $params): View
    {
        $this->assertNotEmbeddedImageRequest();

        // Fetch the current visitor
        $visitor = XF::visitor();

        // Perform a check on that visitor to see if they have the permission we defined earlier.
        $hasPermission = $visitor->hasPermission('general', 'viewProfileToolTip');

        if ($hasPermission) {
            // If the visitor does have permission to view the tool tip.
            // We run the original logic, as it works great as is.
            $user = $this->assertViewableUser($params->user_id, [], true);

            $viewParams = [
                'user' => $user,
            ];

            return $this->view('XF:Member\Tooltip', 'member_tooltip', $viewParams);
        } else {
            // If the visitor doesn't have permission, this is where we change what happens.

            // This loads in a different template.
            // Parameter1 = $viewClass, Parameter2 = $templateName, Parameter3 = $params
            // 1. We still need to load it as a Tooltip.
            // 2. We are changing the template to the template we created earlier.
            // 3. We don't need to pass the user data, so we just send an empty array instead.
            return $this->view('XF:Member\Tooltip', 'no_permission_member_tooltip', []);
        }
    }
}