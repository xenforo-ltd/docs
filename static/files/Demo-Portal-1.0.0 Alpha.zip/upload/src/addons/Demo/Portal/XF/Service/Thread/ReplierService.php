<?php

namespace Demo\Portal\XF\Service\Thread;

use Demo\Portal\Entity\FeaturedThread;

class ReplierService extends XFCP_ReplierService
{
	protected $featureThread;

	public function setFeatureThread($featureThread)
	{
		$this->featureThread = $featureThread;
	}

	protected function _save()
	{
		$post = parent::_save();

		$thread = $this->getThread();

		if ($this->featureThread !== null && $thread->discussion_state == 'visible')
		{
			/** @var FeaturedThread $featuredThread */
			$featuredThread = $thread->getRelationOrDefault('FeaturedThread', false);

			if ($this->featureThread)
			{
				if (!$featuredThread->exists())
				{
					$featuredThread->save();
					$thread->fastUpdate('demo_portal_featured', true);
				}
			}
			else
			{
				if ($featuredThread->exists())
				{
					$featuredThread->delete();
					$thread->fastUpdate('demo_portal_featured', false);
				}
			}
		}

		return $post;
	}
}
