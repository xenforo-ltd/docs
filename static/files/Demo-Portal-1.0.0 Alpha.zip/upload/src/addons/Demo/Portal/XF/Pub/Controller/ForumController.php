<?php

namespace Demo\Portal\XF\Pub\Controller;

use Demo\Portal\XF\Service\Thread\CreatorService;
use XF\Entity\Forum;

class ForumController extends XFCP_ForumController
{
	public function setupThreadCreate(Forum $forum)
	{
		/** @var CreatorService $creator */
		$creator = parent::setupThreadCreate($forum);

		if ($forum->demo_portal_auto_feature)
		{
			$creator->setFeatureThread(true);
		}
		else
		{
			$setOptions = $this->filter('_xfSet', 'array-bool');
			if ($setOptions)
			{
				$thread = $creator->getThread();

				if ($thread->canFeatureUnfeature() && isset($setOptions['featured']))
				{
					$creator->setFeatureThread($this->filter('featured', 'bool'));
				}
			}
		}

		return $creator;
	}
}
