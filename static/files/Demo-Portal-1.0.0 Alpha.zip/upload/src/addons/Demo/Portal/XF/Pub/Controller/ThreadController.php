<?php

namespace Demo\Portal\XF\Pub\Controller;

use Demo\Portal\XF\Service\Thread\EditorService;
use Demo\Portal\XF\Service\Thread\ReplierService;
use XF\Entity\Thread;

class ThreadController extends XFCP_ThreadController
{
	protected function setupThreadEdit(Thread $thread)
	{
		/** @var EditorService $editor */
		$editor = parent::setupThreadEdit($thread);

		$canFeatureUnfeaturePortalThread = $thread->canFeatureUnfeaturePortalThread();
		if ($canFeatureUnfeaturePortalThread)
		{
			$editor->setFeatureThread($this->filter('featured', 'bool'));
		}

		return $editor;
	}

	protected function setupThreadReply(Thread $thread)
	{
		/** @var ReplierService $replier */
		$replier = parent::setupThreadReply($thread);

		$setOptions = $this->filter('_xfSet', 'array-bool');
		if ($thread->canFeatureUnfeaturePortalThread() && isset($setOptions['featured']))
		{
			$replier->setFeatureThread($this->filter('featured', 'bool'));
		}

		return $replier;
	}
}
