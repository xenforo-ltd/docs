<?php

namespace Demo\Portal\XF\Pub\Controller;

use Demo\Portal\XF\Service\Thread\EditorService;
use XF\Entity\Thread;
use XF\Service\Thread\ReplierService;

class ThreadController extends XFCP_ThreadController
{
	public function setupThreadEdit(Thread $thread)
	{
		/** @var EditorService $editor */
		$editor = parent::setupThreadEdit($thread);

		$canFeatureUnfeature = $thread->canFeatureUnfeature();
		if ($canFeatureUnfeature)
		{
			$editor->setFeatureThread($this->filter('featured', 'bool'));
		}

		return $editor;
	}

	public function finalizeThreadReply(ReplierService $replier)
	{
		parent::finalizeThreadReply($replier);

		$setOptions = $this->filter('_xfSet', 'array-bool');
		if ($setOptions)
		{
			$thread = $replier->getThread();

			if ($thread->canFeatureUnfeature() && isset($setOptions['featured']))
			{
				$replier->setFeatureThread($this->filter('featured', 'bool'));
			}
		}
	}
}
