<?php

namespace Demo\Portal\Entity;

use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;

class FeaturedThread extends Entity
{
	public static function getStructure(Structure $structure)
	{
		$structure->table = 'xf_demo_portal_featured_thread';
		$structure->shortName = 'XF:FeaturedThread';
		$structure->primaryKey = 'thread_id';
		$structure->columns = [
			'thread_id' => ['type' => self::UINT, 'required' => true],
			'featured_date' => ['type' => self::UINT, 'default' => time()],
		];
		$structure->getters = [];
		$structure->relations = [
			'Thread' => [
				'entity' => 'XF:Thread',
				'type' => self::TO_ONE,
				'conditions' => 'thread_id',
				'primary' => true,
			],
		];

		return $structure;
	}
}
