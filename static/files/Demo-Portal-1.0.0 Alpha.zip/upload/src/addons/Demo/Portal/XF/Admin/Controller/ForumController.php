<?php

namespace Demo\Portal\XF\Admin\Controller;

use XF\Entity\AbstractNode;
use XF\Entity\Node;
use XF\Mvc\FormAction;

class ForumController extends XFCP_ForumController
{
	protected function saveTypeData(FormAction $form, Node $node, AbstractNode $data)
	{
		parent::saveTypeData($form, $node, $data);

		$form->setup(function () use ($data)
		{
			$data->demo_portal_auto_feature = $this->filter('demo_portal_auto_feature', 'bool');
		});
	}
}
