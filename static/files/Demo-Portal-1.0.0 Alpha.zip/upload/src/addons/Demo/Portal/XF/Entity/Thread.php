<?php

namespace Demo\Portal\XF\Entity;

class Thread extends XFCP_Thread
{
	public function canFeatureUnfeature(&$error = null): bool
	{
		return \XF::visitor()->hasNodePermission($this->node_id, 'demoPortalFeature');
	}
}
