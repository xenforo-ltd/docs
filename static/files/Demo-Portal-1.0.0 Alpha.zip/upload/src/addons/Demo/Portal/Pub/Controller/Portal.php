<?php

namespace Demo\Portal\Pub\Controller;

use Demo\Portal\Repository\FeaturedThread;
use XF\Pub\Controller\AbstractController;
use XF\Repository\AttachmentRepository;

class Portal extends AbstractController
{
	public function actionIndex()
	{
		$page = $this->filterPage();
		$perPage = $this->options()->demoPortalFeaturedPerPage;

		$repo = $this->repository(FeaturedThread::class);

		$finder = $repo->findFeaturedThreadsForPortalView()
			->limit($perPage * 3);

		$featuredThreads = $finder->fetch()
			->filter(function (\Demo\Portal\Entity\FeaturedThread $featuredThread)
			{
				return ($featuredThread->Thread->canView());
			})
			->sliceToPage($page, $perPage);

		$threads = $featuredThreads->pluckNamed('Thread');
		$posts = $threads->pluckNamed('FirstPost', 'first_post_id');

		$attachRepo = $this->repository(AttachmentRepository::class);
		$attachRepo->addAttachmentsToContent($posts, 'post');

		$viewParams = [
			'featuredThreads' => $featuredThreads,
			'total' => $finder->total(),
			'page' => $page,
			'perPage' => $perPage,
		];
		return $this->view('Demo\Portal:View', 'demo_portal_view', $viewParams);
	}
}
