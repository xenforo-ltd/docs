<?php
header('Content-type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=Edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>XenForo 2.0 system requirements test</title>

	<style>
		html
		{
			background: #EEEEEE;
			font: 15px / 1.4 sans-serif;
			font-family: 'Segoe UI', 'Helvetica Neue', Helvetica, Roboto, Oxygen, Ubuntu, Cantarell, 'Fira Sans', 'Droid Sans', sans-serif;
			color: #141414;
			margin: 0;
			padding: 0;
			word-wrap: break-word;
		}

		body
		{
			overflow-y: scroll !important;
			margin: 0;
		}

		.p-pageWrapper
		{
			position: relative;
			display: flex;
			flex-direction: column;
			min-height: 100vh;
		}

		.p-header
		{
			color: #BCDEF5;
			background: #185886;
		}

		.p-header-inner
		{
			max-width: 1200px;
			padding: 0 10px;
			margin: 0 auto;
		}

		.p-header-content
		{
			padding: 6px 0;

			display: flex;
			flex-wrap: wrap;
			justify-content: space-between;
			align-items: center;
			max-width: 100%;
		}

		.p-header-logo
		{
			vertical-align: middle;
			margin-right: auto;
		}

		.p-header-logo.p-header-logo--image img
		{
			vertical-align: bottom;
			max-width: 100%;
			max-height: 200px;
		}

		.p-body
		{
			display: flex;
			align-items: stretch;
		}

		.p-body-inner
		{
			display: flex;
			flex-direction: column;
			width: 100%;
		}

		html .p-body-main
		{
			margin-bottom: auto
		}

		.p-body
		{
			flex-grow: 1;
		}

		.p-body-inner
		{
			max-width: 1200px;
			padding: 0 10px;
			margin: 0 auto;
			padding-top: 10px;
			padding-bottom: 20px;
		}

		.p-body-inner::before,
		.p-body-inner::after
		{
			content: " ";
			display: table;
		}

		.p-body-inner::after
		{
			clear: both;
		}

		.p-body-main
		{
			display: table;
			table-layout: fixed;
			width: 100%;
			margin-top: 10px;
		}

		.p-body-content
		{
			display: table-cell;
			vertical-align: top;
		}

		.p-title
		{
			display: flex;
			flex-wrap: wrap;
			align-items: center;
			max-width: 100%;
			margin-bottom: 5px;
		}

		.p-title-value
		{
			padding: 0;
			margin: 0 0 3px 0;
			font-size: 24px;
			font-weight: 400;
			min-width: 0;
		}

		.blockMessage
		{
			margin: 20px 0;
			padding: 6px 10px;
			color: #141414;
			background: #FEFEFE;

			border-width: 1px;
			border-style: solid;
			border-top-color: #e4e4e4;
			border-right-color: #dcdcdc;
			border-bottom-color: #d2d2d2;
			border-left-color: #dcdcdc;
			border-radius: 4px;
		}

		.blockMessage.blockMessage--success
		{
			border-left: 3px solid #63b265;
			background: #daf3d8;
			color: #3d793f;
		}

		.blockMessage.blockMessage--error
		{
			border-left: 3px solid #c84448;
			background: #fde9e9;
			color: #c84448;
		}

		.p-footer
		{
			font-size: 13px;
			color: #bcdef5;
			background: #0f3652;
		}

		.p-footer-inner
		{
			max-width: 1200px;
			padding: 0 10px;
			margin: 0 auto;
			padding-top: 6px;
			padding-bottom: 10px;
		}

		.p-footer-copyright
		{
			margin-top: 20px;
			text-align: center;
			font-size: 11px;
		}

		.u-concealed
		{
			text-decoration: inherit !important;
			color: inherit !important;
		}
	</style>
</head>
<body>
<div class="p-pageWrapper">
	<header class="p-header">
		<div class="p-header-inner">
			<div class="p-header-content">
				<div class="p-header-logo p-header-logo--image">
					<a href="https://xenforo.com" target="_blank">
						<img src="https://xenforo.com/styles/default/xenforo/logo.png" />
					</a>
				</div>
			</div>
		</div>
	</header>
	<div class="p-body">
		<div class="p-body-inner">
			<div class="p-title ">
				<h1 class="p-title-value">XenForo 2.0 system requirements test</h1>
			</div>
			<div class="p-body-main">
				<div class="p-body-content">
					<?php

					$errors = array();

					$phpVersion = phpversion();
					if (version_compare($phpVersion, '5.4.0', '<'))
					{
						$errors['phpVersion'] = 'PHP 5.4.0 or newer is required. ' . $phpVersion . ' does not meet this requirement. Please ask your host to upgrade PHP.';
					}

					if (!function_exists('mysqli_connect'))
					{
						$errors['mysqlPhp'] = 'The required PHP extension MySQLi could not be found. Please ask your host to install this extension.';
					}

					if (!function_exists('iconv'))
					{
						$errors['iconv'] = 'The required PHP extension Iconv could not be found. Please ask your host to install this extension.';
					}

					if (!function_exists('ctype_alnum'))
					{
						$errors['ctype'] = 'The required PHP extension Ctype could not be found. Please ask your host to install this extension.';
					}

					if (!function_exists('gd_info'))
					{
						$errors['gd'] = 'The required PHP extension GD could not be found. Please ask your host to install this extension.';
					}
					else if (!function_exists('imagecreatefromjpeg'))
					{
						$errors['gdJpeg'] = 'The required PHP extension GD was found, but JPEG support is missing. Please ask your host to add support for JPEG images.';
					}

					if (!function_exists('preg_replace'))
					{
						$errors['pcre'] = 'The required PHP extension PCRE could not be found. Please ask your host to install this extension.';
					}

					if (!function_exists('spl_autoload_register'))
					{
						$errors['spl'] = 'The required PHP extension SPL could not be found. Please ask your host to install this extension.';
					}

					if (!function_exists('json_encode'))
					{
						$errors['json'] = 'The required PHP extension JSON could not be found. Please ask your host to install this extension.';
					}

					if (!extension_loaded('curl'))
					{
						$errors['curl'] = 'The required PHP extension cURL could not be found. Please ask your host to install this extension.';
					}

					if (!class_exists('DOMDocument') || !class_exists('SimpleXMLElement'))
					{
						$errors['xml'] = 'The required PHP extensions for XML handling (DOM and SimpleXML) could not be found. Please ask your host to install this extension.';
					}

					if ($errors)
					{
						?>
						<div class="blockMessage blockMessage--error">
							<strong>Requirements not met</strong>
							<p>The following XenForo requirements were not met. Please contact your host for help.</p>
							<ol>
								<?php foreach ($errors AS $error) { echo "<li>$error</li>"; } ?>
							</ol>
						</div>
						<?php
					}
					else
					{
						?>
						<div class="blockMessage blockMessage--success">
							<strong>Requirements met</strong>
							<div>Your server meets all of XenForo's PHP requirements.</div>
						</div>
						<?php
					}

					?>
					<div class="blockMessage">
						XenForo also requires MySQL 5.5 or newer. Please manually check that you meet this requirement.
					</div>
				</div>
			</div>
		</div>
	</div>
	<footer class="p-footer">
		<div class="p-footer-inner">
			<div class="p-footer-copyright">
				<a href="https://xenforo.com" class="u-concealed">Forum software by XenForo™ <span>©2010-2017 XenForo Ltd.</span></a>
			</div>
		</div>
	</footer>
</body>
</html>