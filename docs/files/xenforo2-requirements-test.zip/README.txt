XenForo 1.0 System Requirements Text Script
-------------------------------------------

This script tests whether you meet the PHP requirements for XenForo 1.0.

Please note that this script does not confirm that you meet the minimum-required
MySQL version (5.0). You must check that manually. If you are unsure where to
find this information, please contact your host.

USAGE
-----

To use this script, simply upload xenforo_requirements.php to your server in any
web-viewable location. Then direct your browser to the URL that corresponds with
that location.

Once you have checked the results from the script, it is recommended that you
remove the file.

Uploading this README.txt file is not necessary.