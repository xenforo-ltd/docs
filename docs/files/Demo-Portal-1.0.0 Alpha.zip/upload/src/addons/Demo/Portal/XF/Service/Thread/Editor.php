<?php

namespace Demo\Portal\XF\Service\Thread;

class Editor extends XFCP_Editor
{
	protected $featureThread;

	public function setFeatureThread($featureThread)
	{
		$this->featureThread = $featureThread;
	}

	protected function _save()
	{
		$thread = parent::_save();

		if ($this->featureThread !== null && $thread->discussion_state == 'visible')
		{
			/** @var \Demo\Portal\Entity\FeaturedThread $featuredThread */
			$featuredThread = $thread->getRelationOrDefault('FeaturedThread');

			if ($this->featureThread)
			{
				$featuredThread->save();

				$thread->fastUpdate('demo_portal_featured', true);
			}
			else
			{
				$featuredThread->delete();

				$thread->fastUpdate('demo_portal_featured', false);
			}
		}

		return $thread;
	}
}

// ******************** FOR IDE AUTO COMPLETE ********************
if (false)
{
	class XFCP_Editor extends \XF\Service\Thread\Editor {}
}