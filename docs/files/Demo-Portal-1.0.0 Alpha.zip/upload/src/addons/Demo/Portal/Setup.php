<?php

namespace Demo\Portal;

class Setup extends \XF\AddOn\AbstractSetup
{
	use \XF\AddOn\StepRunnerInstallTrait;
	use \XF\AddOn\StepRunnerUpgradeTrait;
	use \XF\AddOn\StepRunnerUninstallTrait;

	public function installStep1()
	{
		$this->query("
			ALTER TABLE xf_forum
			ADD demo_portal_auto_feature TINYINT(3) UNSIGNED NOT NULL DEFAULT 0
		");
	}

	public function installStep2()
	{
		$this->query("
			ALTER TABLE xf_thread
			ADD demo_portal_featured TINYINT(3) UNSIGNED NOT NULL DEFAULT 0
		");
	}

	public function installStep3()
	{
		$db = $this->db();
		$schemaManager = $db->getSchemaManager();
		$defaultTableConfig = $schemaManager->getTableConfigSql();

		$this->query("
			CREATE TABLE xf_demo_portal_featured_thread (
				thread_id INT(10) UNSIGNED NOT NULL,
				featured_date INT(10) UNSIGNED NOT NULL,
				PRIMARY KEY (thread_id)
			) {$defaultTableConfig}
		");
	}
	
	public function installStep4()
	{
		$this->query("
			INSERT INTO xf_widget
				(widget_key, definition_id, position_id, display_order, active, options)
			VALUES
				('demo_portal_view_members_online',		'members_online',		'demo_portal_view_sidebar',	20, 	1, '{\"limit\":50,\"staffOnline\":true,\"followedOnline\":true}'),
				('demo_portal_view_new_posts',			'new_posts',			'demo_portal_view_sidebar',	30, 	1, '{\"limit\":5,\"filter\":\"unread\"}'),
				('demo_portal_view_new_profile_posts',	'new_profile_posts',	'demo_portal_view_sidebar',	40, 	1, '{\"limit\":5}'),
				('demo_portal_view_board_totals',		'board_totals',			'demo_portal_view_sidebar',	50,		1, '[]'),
				('demo_portal_view_share_page',			'share_page',			'demo_portal_view_sidebar',	60, 	1, '{\"vertical\":true,\"counter\":true}')
		");

		\XF::runOnce('widgetCacheRebuild', function()
		{
			\XF::repository('XF:Widget')->rebuildWidgetCache();
		});
	}

	public function uninstallStep1()
	{
		$this->query("
			ALTER TABLE xf_forum
			DROP demo_portal_auto_feature
		");
	}

	public function uninstallStep2()
	{
		$this->query("
			ALTER TABLE xf_thread
			DROP demo_portal_featured
		");
	}

	public function uninstallStep3()
	{
		$this->query("
			DROP TABLE xf_demo_portal_featured_thread
		");
	}
}