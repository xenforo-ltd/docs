<?php

namespace Demo\Portal\XF\Entity;

class Thread extends XFCP_Thread
{
	public function canFeatureUnfeature()
	{
		return \XF::visitor()->hasNodePermission($this->node_id, 'demoPortalFeature');
	}
}

// ******************** FOR IDE AUTO COMPLETE ********************
if (false)
{
	class XFCP_Thread extends \XF\Entity\Thread {}
}